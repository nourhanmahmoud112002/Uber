﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
namespace Uber_App
{
    public partial class Passenger_Home_Page : Form
    {
        string connection_string = "Data Source=ORCL; User Id=scott; Password=scott;";
        OracleConnection database_connection;
        public Passenger_Home_Page()
        {
            InitializeComponent();
        }

        private void update_passenger_info_btn_Click(object sender, EventArgs e)
        {
            User_Info user_info_page = new User_Info();
            user_info_page.Show();
            this.Hide();
        }

        private void Passenger_Home_Page_Load(object sender, EventArgs e)
        {
            user_id.Text = Globals.loggedInUserId.ToString();
        }
    }
}
