﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uber_App
{
    public class Globals
    {
        public static int loggedInUserId;
        public static string loggedInUserType;
        public static string connection_string = "Data Source=ORCL; User Id=scott; Password=scott;";
    }
}
