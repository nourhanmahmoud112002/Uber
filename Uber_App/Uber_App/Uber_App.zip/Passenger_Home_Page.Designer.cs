﻿
namespace Uber_App
{
    partial class Passenger_Home_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.update_passenger_info_btn = new System.Windows.Forms.Button();
            this.user_id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // update_passenger_info_btn
            // 
            this.update_passenger_info_btn.Location = new System.Drawing.Point(241, 317);
            this.update_passenger_info_btn.Name = "update_passenger_info_btn";
            this.update_passenger_info_btn.Size = new System.Drawing.Size(179, 39);
            this.update_passenger_info_btn.TabIndex = 0;
            this.update_passenger_info_btn.Text = "Update Info";
            this.update_passenger_info_btn.UseVisualStyleBackColor = true;
            this.update_passenger_info_btn.Click += new System.EventHandler(this.update_passenger_info_btn_Click);
            // 
            // user_id
            // 
            this.user_id.Location = new System.Drawing.Point(274, 129);
            this.user_id.Name = "user_id";
            this.user_id.Size = new System.Drawing.Size(100, 22);
            this.user_id.TabIndex = 1;
            // 
            // Passenger_Home_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.user_id);
            this.Controls.Add(this.update_passenger_info_btn);
            this.Name = "Passenger_Home_Page";
            this.Text = "Passenger_Home_Page";
            this.Load += new System.EventHandler(this.Passenger_Home_Page_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button update_passenger_info_btn;
        private System.Windows.Forms.TextBox user_id;
    }
}